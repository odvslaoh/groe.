const express = require('express');
const cors = require('cors');
const helmet = require('helmet');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(helmet());
app.use(express.json());

// Fake In-Memory DB
const users = [];
const videos = [];
const marketplaceProjects = [];

// API Endpoints
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok', message: 'GROE AI API is running' });
});

// Auth endpoints (Mock)
app.post('/api/auth/register', (req, res) => {
  const { email, password } = req.body;
  // Handle registration & JWT generation
  res.status(201).json({ message: 'User registered securely' });
});

app.post('/api/auth/login', (req, res) => {
  // Handle login
  res.status(200).json({ token: 'mock-jwt-token', user: { id: 1, email: req.body.email } });
});

// Video Generator (Mock)
app.post('/api/videos/generate', (req, res) => {
  // Handle video generation logic using external AI API
  res.status(202).json({ message: 'Video generation started', videoId: 'mock-vid-123' });
});

// Marketplace (Mock)
app.get('/api/marketplace/projects', (req, res) => {
  res.status(200).json(marketplaceProjects);
});

// Bots / Security Logs (Mock)
app.get('/api/admin/logs', (req, res) => {
  // Mock bot logs for admin
  res.status(200).json([
    { bot: 'Bot 1', action: 'System error check', status: 'Clear', time: new Date() },
    { bot: 'Bot 3', action: 'Security scan', status: 'No vulnerabilities found', time: new Date() },
  ]);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
