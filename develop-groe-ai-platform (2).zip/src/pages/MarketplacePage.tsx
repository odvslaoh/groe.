import { useState } from 'react';
import { Store, Building2, UserCircle, Briefcase, Plus, Filter, Search, CheckCircle2, FileSignature, Handshake } from 'lucide-react';

const mockProjects = [
  { id: 1, title: 'AI Automation Software', category: 'SaaS', price: '$5,000 - $10,000', owner: 'TechFlow Inc.', type: 'Company', status: 'Seeking Investors' },
  { id: 2, title: 'E-commerce Plugin', category: 'Retail', price: '$2,000', owner: 'John Doe', type: 'Seller', status: 'For Sale' },
  { id: 3, title: 'Blockchain Logistics App', category: 'Logistics', price: '$15,000+', owner: 'Sarah Connor', type: 'Investor Seeking Co-founders', status: 'Open' },
  { id: 4, title: 'Machine Learning Models library', category: 'AI', price: '$8,000', owner: 'DataMinds LLC', type: 'Company', status: 'For Sale' },
];

export default function MarketplacePage() {
  const [role, setRole] = useState<string | null>(null);

  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl">
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 flex items-center gap-3">
          <Store className="text-primary" /> Business World Marketplace
        </h1>
        <p className="text-muted-foreground text-lg max-w-3xl">
          Connect securely with investors, sellers, and companies. Engage in verified digital contract signing and authenticated transactions.
        </p>
      </div>

      {/* Role Selection / Registration Alert */}
      {!role && (
        <div className="bg-gradient-to-r from-primary/10 to-transparent border border-primary/20 rounded-2xl p-6 md:p-8 mb-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl font-bold mb-2">Register Your Profile</h2>
            <p className="text-muted-foreground">To add projects or engage in contracts, you must register a business role.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button onClick={() => setRole('Investor')} className="px-6 py-2.5 bg-card border border-border hover:border-primary rounded-xl font-bold flex items-center gap-2 transition-colors">
              <UserCircle size={20} className="text-blue-500" /> Investor
            </button>
            <button onClick={() => setRole('Seller')} className="px-6 py-2.5 bg-card border border-border hover:border-primary rounded-xl font-bold flex items-center gap-2 transition-colors">
              <Briefcase size={20} className="text-emerald-500" /> Seller
            </button>
            <button onClick={() => setRole('Company')} className="px-6 py-2.5 bg-card border border-border hover:border-primary rounded-xl font-bold flex items-center gap-2 transition-colors">
              <Building2 size={20} className="text-purple-500" /> Company
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Filters */}
        <div className="w-full md:w-64 shrink-0 space-y-6">
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
            <h3 className="font-bold flex items-center gap-2 mb-4"><Filter size={18} /> Filters</h3>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold text-muted-foreground mb-2 block">Category</label>
                <select className="w-full p-2 bg-muted rounded-lg text-sm border-none focus:ring-1 focus:ring-primary">
                  <option>All Categories</option>
                  <option>AI / Machine Learning</option>
                  <option>SaaS</option>
                  <option>E-commerce</option>
                  <option>Logistics</option>
                </select>
              </div>
              
              <div>
                <label className="text-sm font-semibold text-muted-foreground mb-2 block">Project Type</label>
                <select className="w-full p-2 bg-muted rounded-lg text-sm border-none focus:ring-1 focus:ring-primary">
                  <option>Any</option>
                  <option>For Sale</option>
                  <option>Seeking Investment</option>
                  <option>Partnership</option>
                </select>
              </div>
            </div>
          </div>
          
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm space-y-4">
             <h3 className="font-bold flex items-center gap-2"><CheckCircle2 size={18} className="text-emerald-500"/> Verified Escrow</h3>
             <p className="text-xs text-muted-foreground">All transactions are secured via digital contracts and identity verification.</p>
          </div>
        </div>

        {/* Listings Area */}
        <div className="flex-1">
          {/* Top Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
            <div className="relative w-full sm:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
              <input 
                type="text" 
                placeholder="Search projects..." 
                className="w-full pl-10 pr-4 py-2.5 bg-card border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary text-sm"
              />
            </div>
            {role && (
              <button className="w-full sm:w-auto px-6 py-2.5 bg-primary text-primary-foreground font-bold rounded-xl hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                <Plus size={18} /> Add Project
              </button>
            )}
          </div>

          {/* Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {mockProjects.map(project => (
              <div key={project.id} className="bg-card border border-border rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className="text-xs font-bold text-primary bg-primary/10 px-2.5 py-1 rounded-md uppercase tracking-wider">{project.category}</span>
                    <h3 className="text-xl font-bold mt-2 leading-tight">{project.title}</h3>
                  </div>
                  <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">{project.price}</span>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
                  <UserCircle size={16} /> {project.owner} • <span className="font-medium">{project.type}</span>
                </div>
                
                <div className="mt-auto flex gap-3 pt-4 border-t border-border/50">
                  <button className="flex-1 py-2.5 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/20 font-bold rounded-xl transition-colors flex items-center justify-center gap-2 text-sm">
                    <Handshake size={16} /> Contact
                  </button>
                  <button className="flex-1 py-2.5 bg-rose-500 text-white hover:bg-rose-600 font-bold rounded-xl transition-colors flex items-center justify-center gap-2 text-sm shadow-sm">
                    <FileSignature size={16} /> Buy / Contract
                  </button>
                </div>
              </div>
            ))}
          </div>
          
        </div>
      </div>
    </div>
  );
}
