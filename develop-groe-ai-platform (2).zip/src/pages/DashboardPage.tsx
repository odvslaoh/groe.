import React, { useState } from 'react';
import { User, Settings, CreditCard, Shield, Activity, LogOut, Moon, Sun, Monitor } from 'lucide-react';

const mockLogs = [
  { id: 1, bot: 'Bot 1 (System)', action: 'Error detection sweep', status: 'Clear', time: '10 mins ago' },
  { id: 2, bot: 'Bot 2 (Fixer)', action: 'Cache cleared automatically', status: 'Success', time: '1 hour ago' },
  { id: 3, bot: 'Bot 3 (Security)', action: 'Vulnerability scan', status: 'Secure', time: '2 hours ago' },
  { id: 4, bot: 'Bot 4 (Fraud)', action: 'Payment validation check', status: 'Verified', time: '1 day ago' },
];

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState('profile');
  const [username, setUsername] = useState('Ammar123');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Profile updated successfully.');
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl flex flex-col md:flex-row gap-8">
      {/* Sidebar */}
      <div className="w-full md:w-64 shrink-0 space-y-2">
        <h2 className="text-sm font-black uppercase tracking-widest text-muted-foreground px-4 mb-4">Dashboard</h2>
        {[
          { id: 'profile', icon: User, label: 'Profile Settings' },
          { id: 'billing', icon: CreditCard, label: 'Billing & Subscriptions' },
          { id: 'appearance', icon: Monitor, label: 'Appearance' },
          { id: 'security', icon: Shield, label: 'System Security Logs' },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-all ${
              activeTab === tab.id ? 'bg-primary text-primary-foreground shadow-md' : 'hover:bg-muted text-muted-foreground hover:text-foreground'
            }`}
          >
            <tab.icon size={18} /> {tab.label}
          </button>
        ))}
        
        <div className="pt-8 px-4">
           <button className="flex items-center gap-2 text-rose-500 font-bold hover:text-rose-600 transition-colors">
             <LogOut size={18} /> Sign Out
           </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 bg-card border border-border rounded-3xl p-6 md:p-8 shadow-sm">
        {activeTab === 'profile' && (
          <div className="max-w-xl">
            <h1 className="text-2xl font-extrabold mb-6 flex items-center gap-2"><Settings className="text-primary" /> Profile Settings</h1>
            <form onSubmit={handleSave} className="space-y-6">
              <div>
                <label className="text-sm font-bold block mb-2">Username</label>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full p-3 bg-muted border-none rounded-xl focus:ring-2 focus:ring-primary text-sm font-medium" 
                />
              </div>
              <div>
                <label className="text-sm font-bold block mb-2">Email Address</label>
                <input 
                  type="email" 
                  defaultValue="user@groeai.com"
                  disabled
                  className="w-full p-3 bg-muted/50 text-muted-foreground border-none rounded-xl text-sm font-medium cursor-not-allowed" 
                />
                <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                  <Shield size={14} className="text-emerald-500" /> Secure encrypted email address.
                </p>
              </div>
              <button type="submit" className="px-6 py-3 bg-primary text-primary-foreground font-bold rounded-xl hover:bg-primary/90 transition-colors">
                Save Changes
              </button>
            </form>
          </div>
        )}

        {activeTab === 'billing' && (
          <div>
            <h1 className="text-2xl font-extrabold mb-6 flex items-center gap-2"><CreditCard className="text-primary" /> Billing Details</h1>
            <div className="p-6 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl text-white mb-8 shadow-xl">
              <h3 className="text-sm font-medium uppercase tracking-widest opacity-80 mb-1">Current Plan</h3>
              <div className="text-3xl font-black mb-4">Monthly Pro</div>
              <div className="flex justify-between items-end">
                <span className="text-xl font-bold">5 Videos left</span>
                <button className="bg-white text-indigo-900 px-4 py-2 rounded-lg font-bold text-sm hover:bg-slate-100">Upgrade</button>
              </div>
            </div>
            
            <h3 className="text-lg font-bold mb-4">Payment Methods</h3>
            <div className="border border-border p-4 rounded-xl flex justify-between items-center mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-8 bg-slate-200 dark:bg-slate-800 rounded flex items-center justify-center font-bold text-xs">VISA</div>
                <div>
                  <div className="font-bold text-sm">•••• •••• •••• 4242</div>
                  <div className="text-xs text-muted-foreground">Expires 12/26</div>
                </div>
              </div>
              <button className="text-sm font-bold text-rose-500 hover:underline">Remove</button>
            </div>
            <button className="px-4 py-2 border border-border hover:border-primary font-bold rounded-lg text-sm transition-colors">
              + Add Payment Method
            </button>
          </div>
        )}
        
        {activeTab === 'appearance' && (
          <div>
            <h1 className="text-2xl font-extrabold mb-6 flex items-center gap-2"><Monitor className="text-primary" /> Appearance</h1>
            <div className="grid grid-cols-2 gap-4 max-w-sm">
              <button className="flex flex-col items-center gap-3 p-6 border-2 border-primary bg-primary/5 rounded-2xl">
                <Moon size={32} />
                <span className="font-bold text-sm">Dark Theme</span>
              </button>
              <button className="flex flex-col items-center gap-3 p-6 border-2 border-border hover:border-primary/50 bg-card rounded-2xl text-muted-foreground">
                <Sun size={32} />
                <span className="font-bold text-sm">Light Theme</span>
              </button>
            </div>
          </div>
        )}

        {activeTab === 'security' && (
          <div>
            <h1 className="text-2xl font-extrabold mb-2 flex items-center gap-2"><Activity className="text-primary" /> System Bot Logs</h1>
            <p className="text-muted-foreground text-sm mb-6">Real-time logs from our 4 AI security and optimization bots.</p>
            
            <div className="space-y-4">
              {mockLogs.map(log => (
                <div key={log.id} className="p-4 border border-border rounded-xl bg-muted/30 flex justify-between items-center">
                  <div className="flex items-start gap-4">
                    <div className="mt-1 p-2 bg-background rounded-full border border-border">
                      <Shield size={16} className={log.status === 'Clear' || log.status === 'Success' || log.status === 'Secure' || log.status === 'Verified' ? 'text-emerald-500' : 'text-rose-500'} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm">{log.bot}</h4>
                      <p className="text-xs text-muted-foreground">{log.action}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded mb-1 inline-block uppercase tracking-wider">{log.status}</div>
                    <div className="text-xs text-muted-foreground">{log.time}</div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl text-sm">
              <strong className="text-amber-600 dark:text-amber-400">Notice:</strong> Bots automatically send critical security and fraud reports directly to admin emails.
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
