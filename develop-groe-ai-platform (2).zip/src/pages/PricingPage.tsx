import { CheckCircle2, CreditCard, Sparkles } from 'lucide-react';

const plans = [
  {
    name: 'Free Starter',
    price: '$0',
    period: 'forever',
    description: 'Perfect for trying out the GROE AI capabilities.',
    features: ['3 AI Video Generations', 'Standard Quality', 'Community Support', 'Watermarked Export'],
    buttonText: 'Get Started',
    popular: false,
    color: 'bg-slate-100 dark:bg-slate-800'
  },
  {
    name: 'Monthly Pro',
    price: '$50',
    period: '/month',
    description: 'For regular creators and small businesses.',
    features: ['5 High-Res AI Videos', 'No Watermarks', 'Email Support', 'Priority Generation Queue', 'Access to Marketplace'],
    buttonText: 'Subscribe Monthly',
    popular: true,
    color: 'bg-primary text-primary-foreground border-primary shadow-xl scale-105'
  },
  {
    name: 'Weekly Elite',
    price: '$100',
    period: '/week',
    description: 'High volume generation for intense marketing campaigns.',
    features: ['10 4K AI Videos', 'Custom Aspect Ratios', 'Dedicated Account Manager', 'Advanced Bot Security', 'Premium Marketplace Listing'],
    buttonText: 'Subscribe Weekly',
    popular: false,
    color: 'bg-card border-border'
  },
  {
    name: 'Yearly Enterprise',
    price: '$250',
    period: '/year',
    description: 'Best value for enterprise teams and agencies.',
    features: ['100 4K AI Videos', 'Full API Access', 'Custom AI Model Tuning', 'White-labeling Options', 'Zero Marketplace Fees'],
    buttonText: 'Subscribe Yearly',
    popular: false,
    color: 'bg-gradient-to-br from-indigo-500 to-purple-600 text-white border-none shadow-2xl'
  }
];

export default function PricingPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-7xl">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">Simple, Transparent Pricing</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Choose the plan that fits your creative and business needs. Upgrade, downgrade, or cancel at any time securely.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
        {plans.map((plan, i) => (
          <div 
            key={i} 
            className={`rounded-3xl p-8 flex flex-col relative ${plan.color} ${!plan.popular && !plan.color.includes('gradient') ? 'border border-border bg-card' : ''} transition-transform hover:-translate-y-1 duration-300`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-pink-500 to-orange-400 text-white text-xs font-black uppercase tracking-widest py-1.5 px-4 rounded-full shadow-lg flex items-center gap-1">
                <Sparkles size={14} /> Most Popular
              </div>
            )}
            
            <h3 className={`text-2xl font-bold mb-2 ${plan.popular ? 'text-primary-foreground' : ''}`}>{plan.name}</h3>
            <p className={`text-sm mb-6 ${plan.popular ? 'text-primary-foreground/80' : 'text-muted-foreground'}`}>{plan.description}</p>
            
            <div className="mb-6 flex items-baseline gap-1">
              <span className={`text-5xl font-black tracking-tighter ${plan.popular ? 'text-primary-foreground' : ''}`}>{plan.price}</span>
              <span className={`font-medium ${plan.popular ? 'text-primary-foreground/80' : 'text-muted-foreground'}`}>{plan.period}</span>
            </div>

            <ul className="space-y-4 mb-8 flex-1">
              {plan.features.map((feature, j) => (
                <li key={j} className="flex items-start gap-3 text-sm font-medium">
                  <CheckCircle2 size={18} className={`shrink-0 ${plan.popular ? 'text-emerald-400' : plan.color.includes('gradient') ? 'text-emerald-300' : 'text-emerald-500'}`} />
                  <span className={plan.popular || plan.color.includes('gradient') ? 'text-white/90' : 'text-foreground/80'}>{feature}</span>
                </li>
              ))}
            </ul>

            <button className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-colors ${
              plan.popular 
                ? 'bg-white text-primary hover:bg-slate-100' 
                : plan.color.includes('gradient')
                  ? 'bg-white text-indigo-600 hover:bg-slate-100'
                  : 'bg-primary text-primary-foreground hover:bg-primary/90'
            }`}>
              <CreditCard size={18} /> {plan.buttonText}
            </button>
          </div>
        ))}
      </div>
      
      <div className="mt-16 bg-muted/30 border border-border rounded-2xl p-8 text-center max-w-3xl mx-auto">
        <h3 className="text-xl font-bold mb-2">Secure Payments Guarantee</h3>
        <p className="text-muted-foreground text-sm">
           All transactions are processed securely using standard encryption protocols. Your financial data is never stored directly on GROE AI servers. For custom enterprise billing, please contact our support team.
        </p>
      </div>
    </div>
  );
}
