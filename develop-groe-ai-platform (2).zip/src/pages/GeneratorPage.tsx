import { useState } from 'react';
import { Video, Upload, Monitor, Smartphone, Wand2, Loader2, Play } from 'lucide-react';
import { motion } from 'framer-motion';

export default function GeneratorPage() {
  const [prompt, setPrompt] = useState('');
  const [device, setDevice] = useState('PC'); // PC, Phone, iPhone
  const [mode, setMode] = useState('text-to-video'); // text-to-video, enhance
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleGenerate = () => {
    if (!prompt.trim() && mode === 'text-to-video') return;
    setIsGenerating(true);
    setResult(null);

    // Simulate AI generation delay
    setTimeout(() => {
      setIsGenerating(false);
      setResult('https://www.w3schools.com/html/mov_bbb.mp4'); // Sample placeholder video
    }, 4000);
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-5xl">
      <div className="mb-10 text-center">
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4 flex items-center justify-center gap-3">
          <Wand2 className="text-primary" /> AI Video Studio
        </h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Create breathtaking videos from text prompts or upload existing footage to enhance quality using our advanced AI models.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls Sidebar */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h3 className="text-lg font-bold mb-4">Generation Mode</h3>
            <div className="flex bg-muted p-1 rounded-xl mb-6">
              <button
                onClick={() => setMode('text-to-video')}
                className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${mode === 'text-to-video' ? 'bg-background shadow-sm' : 'hover:bg-background/50'}`}
              >
                Text to Video
              </button>
              <button
                onClick={() => setMode('enhance')}
                className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${mode === 'enhance' ? 'bg-background shadow-sm' : 'hover:bg-background/50'}`}
              >
                Enhance Video
              </button>
            </div>

            <h3 className="text-lg font-bold mb-4">Target Device Aspect Ratio</h3>
            <div className="grid grid-cols-3 gap-2 mb-6">
              {[
                { id: 'PC', icon: Monitor, label: '16:9 PC' },
                { id: 'Phone', icon: Smartphone, label: '9:16 Android' },
                { id: 'iPhone', icon: Smartphone, label: '9:16 iOS' },
              ].map(dev => (
                <button
                  key={dev.id}
                  onClick={() => setDevice(dev.id)}
                  className={`flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                    device === dev.id ? 'border-primary bg-primary/5 text-primary' : 'border-border hover:border-primary/50 text-muted-foreground'
                  }`}
                >
                  <dev.icon size={20} />
                  <span className="text-xs font-semibold">{dev.id}</span>
                </button>
              ))}
            </div>

            {mode === 'text-to-video' ? (
              <div className="space-y-3">
                <label className="text-sm font-bold">Prompt</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe your video... e.g. A futuristic city at sunset with flying cars..."
                  className="w-full h-32 p-3 bg-muted border-none rounded-xl text-sm focus:ring-2 focus:ring-primary resize-none"
                />
              </div>
            ) : (
              <div className="space-y-3">
                <label className="text-sm font-bold">Upload Source Video</label>
                <div className="w-full h-32 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-2 hover:bg-muted/50 transition-colors cursor-pointer text-muted-foreground hover:text-foreground">
                  <Upload size={24} />
                  <span className="text-sm font-medium">Click to upload (.mp4)</span>
                </div>
              </div>
            )}

            <button
              onClick={handleGenerate}
              disabled={isGenerating || (!prompt.trim() && mode === 'text-to-video')}
              className="w-full mt-6 py-3 bg-primary text-primary-foreground font-bold rounded-xl hover:bg-primary/90 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isGenerating ? (
                <><Loader2 className="animate-spin" size={20} /> Generating...</>
              ) : (
                <><Video size={20} /> Generate</>
              )}
            </button>
            <p className="text-xs text-center text-muted-foreground mt-3">
              Uses 1 video generation credit.
            </p>
          </div>
        </div>

        {/* Preview Area */}
        <div className="lg:col-span-2 flex flex-col items-center justify-center min-h-[500px] bg-black/5 dark:bg-white/5 border border-border rounded-3xl overflow-hidden relative">
          {isGenerating ? (
            <div className="flex flex-col items-center gap-4 text-muted-foreground">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
              >
                <Wand2 size={48} className="text-primary opacity-50" />
              </motion.div>
              <p className="font-medium animate-pulse">Rendering AI frames...</p>
            </div>
          ) : result ? (
            <div className="w-full h-full bg-black relative flex items-center justify-center group">
              <video
                src={result}
                controls
                autoPlay
                className={`max-w-full max-h-full ${
                  device === 'PC' ? 'aspect-video' : 'aspect-[9/16] h-[600px]'
                }`}
              />
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4 text-muted-foreground opacity-50">
              <Play size={64} />
              <p className="font-medium">Your generated video will appear here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
