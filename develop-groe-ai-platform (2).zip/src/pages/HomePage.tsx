import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Video, Store, Shield } from 'lucide-react';

export default function HomePage() {
  const [showCreator, setShowCreator] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowCreator(false);
    }, 6000); // Hide after 6 seconds

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex-1 flex flex-col items-center">
      {/* Hero Section with Animated Background */}
      <section className="w-full min-h-[90vh] animated-bg flex flex-col items-center justify-center text-center px-4 relative overflow-hidden">
        
        {/* Creator Overlay */}
        <AnimatePresence>
          {showCreator && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5 }}
              className="absolute inset-0 z-10 flex items-center justify-center bg-black/80 backdrop-blur-sm"
            >
              <h2 className="text-3xl md:text-5xl font-bold text-white tracking-wider">
                صنع بواسطة مولاي عمار محمود سليمان
              </h2>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="z-0 space-y-8 max-w-4xl mx-auto">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-5xl md:text-7xl font-extrabold text-white tracking-tighter drop-shadow-xl"
          >
            The Future of <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">AI Video</span> is Here.
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-lg md:text-2xl text-slate-200 max-w-2xl mx-auto font-medium drop-shadow-md"
          >
            Generate stunning AI videos, join the business marketplace, and scale your creativity with GROE AI.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link
              to="/generator"
              className="px-8 py-4 rounded-full bg-white text-indigo-900 font-bold text-lg hover:bg-slate-100 hover:scale-105 transition-all shadow-xl flex items-center gap-2"
            >
              <Video size={20} /> Try Generator
            </Link>
            <Link
              to="/marketplace"
              className="px-8 py-4 rounded-full bg-transparent border-2 border-white text-white font-bold text-lg hover:bg-white/10 hover:scale-105 transition-all shadow-xl flex items-center gap-2"
            >
              <Store size={20} /> Business World
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="w-full py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Why Choose GROE AI?</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Our platform integrates cutting-edge AI video generation with a secure marketplace for businesses and creators.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="p-6 rounded-2xl bg-card border border-border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-indigo-500/10 text-indigo-500 flex items-center justify-center mb-4">
                <Video size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">High-Fidelity Generation</h3>
              <p className="text-muted-foreground leading-relaxed">
                Convert text to video or enhance existing videos with stunning clarity. Optimized for Phone, PC, and iPhone aspect ratios.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-card border border-border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center mb-4">
                <Store size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Business Marketplace</h3>
              <p className="text-muted-foreground leading-relaxed">
                Connect with investors, sellers, and companies. Secure digital contract signing and verified identity transactions.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-card border border-border shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-rose-500/10 text-rose-500 flex items-center justify-center mb-4">
                <Shield size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Enterprise Security</h3>
              <p className="text-muted-foreground leading-relaxed">
                Protected by 4 internal AI bots monitoring system health, fraud detection, and robust content moderation.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
