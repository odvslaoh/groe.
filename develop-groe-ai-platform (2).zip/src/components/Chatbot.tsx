import { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, User } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { text: "Hello! I am GROE, your AI assistant. How can I help you with our platform today?", isBot: true }
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = input.trim();
    setMessages(prev => [...prev, { text: userMessage, isBot: false }]);
    setInput('');

    // Simulate bot thinking
    setTimeout(() => {
      let botResponse = "I'm sorry, I can only assist with platform-related inquiries like video generation, marketplace rules, and pricing.";
      
      const lowerInput = userMessage.toLowerCase();
      
      // Basic predefined responses
      if (lowerInput.includes('admin') || lowerInput.includes('source code') || lowerInput.includes('data')) {
        botResponse = "I cannot provide admin data, source code, or other users' data. This is strictly prohibited by our security policies.";
      } else if (lowerInput.includes('hello') || lowerInput.includes('hi')) {
        botResponse = "Hello! Do you need help navigating the Business Marketplace or the Video Generator?";
      } else if (lowerInput.includes('price') || lowerInput.includes('cost') || lowerInput.includes('subscription')) {
        botResponse = "Our plans start at a Free tier with 3 videos. We also offer Monthly ($50), Weekly ($100), and Yearly ($250) plans.";
      } else if (lowerInput.includes('marketplace') || lowerInput.includes('business')) {
        botResponse = "The Business World marketplace allows you to register as an Investor, Seller, or Company. You can browse projects and securely contract with others.";
      } else if (lowerInput.includes('tutorial') || lowerInput.includes('how to')) {
        botResponse = "Would you like me to guide you through a quick tutorial on how to use the AI Video Generator? (Yes/No)";
      } else if (lowerInput === 'yes') {
        botResponse = "Great! 1. Go to the AI Generator page. 2. Write your prompt or upload a source video. 3. Select your output quality and click Generate!";
      }

      setMessages(prev => [...prev, { text: botResponse, isBot: true }]);
    }, 1000);
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 p-4 rounded-full bg-primary text-primary-foreground shadow-xl hover:scale-110 transition-transform z-50 ${isOpen ? 'hidden' : 'flex'}`}
      >
        <MessageSquare size={24} />
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="fixed bottom-6 right-6 w-80 sm:w-96 bg-card border border-border rounded-2xl shadow-2xl flex flex-col overflow-hidden z-50 h-[500px] max-h-[80vh]"
          >
            {/* Header */}
            <div className="bg-primary text-primary-foreground p-4 flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold">
                <Bot size={20} /> GROE Assistant
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:bg-primary/80 p-1 rounded-md transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 bg-muted/20">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.isBot ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[80%] p-3 rounded-2xl flex items-start gap-2 ${
                    msg.isBot ? 'bg-secondary text-secondary-foreground rounded-tl-none' : 'bg-primary text-primary-foreground rounded-tr-none'
                  }`}>
                    {msg.isBot ? <Bot size={16} className="mt-0.5 shrink-0" /> : <User size={16} className="mt-0.5 shrink-0" />}
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-3 border-t border-border bg-card flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask GROE something..."
                className="flex-1 bg-muted border-none rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button
                onClick={handleSend}
                className="p-2 bg-primary text-primary-foreground rounded-full hover:bg-primary/90 transition-colors"
              >
                <Send size={18} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
