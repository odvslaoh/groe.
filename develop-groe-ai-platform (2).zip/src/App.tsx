import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Sun, Moon, Sparkles, Video, Store, CreditCard, LayoutDashboard, LogIn } from 'lucide-react';

// Pages
import HomePage from './pages/HomePage';
import GeneratorPage from './pages/GeneratorPage';
import MarketplacePage from './pages/MarketplacePage';
import PricingPage from './pages/PricingPage';
import DashboardPage from './pages/DashboardPage';
import LoginPage from './pages/LoginPage';

// Components
import Chatbot from './components/Chatbot';

function Layout({ children, toggleTheme, isDark }: { children: React.ReactNode, toggleTheme: () => void, isDark: boolean }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: 'Home', path: '/', icon: <Sparkles size={18} /> },
    { name: 'AI Generator', path: '/generator', icon: <Video size={18} /> },
    { name: 'Business World', path: '/marketplace', icon: <Store size={18} /> },
    { name: 'Pricing', path: '/pricing', icon: <CreditCard size={18} /> },
  ];

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'dark' : 'light'}`}>
      <div className="flex-1 flex flex-col bg-background text-foreground transition-colors duration-300 relative">
        <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container mx-auto px-4 h-16 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2 font-bold text-2xl tracking-tighter">
              <span className="bg-gradient-to-r from-indigo-500 to-purple-600 bg-clip-text text-transparent">GROE AI</span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-6">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-1.5 text-sm font-medium transition-colors hover:text-primary ${
                    location.pathname === link.path ? 'text-primary' : 'text-muted-foreground'
                  }`}
                >
                  {link.icon}
                  {link.name}
                </Link>
              ))}
            </nav>

            <div className="hidden md:flex items-center gap-4">
              <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-muted transition-colors">
                {isDark ? <Sun size={20} /> : <Moon size={20} />}
              </button>
              <Link to="/login" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-2">
                <LogIn size={18} /> Login
              </Link>
              <Link
                to="/dashboard"
                className="bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors flex items-center gap-2"
              >
                <LayoutDashboard size={18} /> Dashboard
              </Link>
            </div>

            {/* Mobile Menu Toggle */}
            <button
              className="md:hidden p-2 rounded-md hover:bg-muted"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Nav */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="md:hidden border-b border-border bg-background"
              >
                <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
                  {navLinks.map((link) => (
                    <Link
                      key={link.path}
                      to={link.path}
                      className="flex items-center gap-2 text-base font-medium py-2 text-muted-foreground hover:text-primary"
                    >
                      {link.icon}
                      {link.name}
                    </Link>
                  ))}
                  <div className="h-px bg-border my-2" />
                  <div className="flex items-center justify-between py-2">
                    <span className="font-medium">Theme</span>
                    <button onClick={toggleTheme} className="p-2 rounded-full bg-muted">
                      {isDark ? <Sun size={20} /> : <Moon size={20} />}
                    </button>
                  </div>
                  <Link to="/login" className="flex items-center gap-2 font-medium py-2">
                    <LogIn size={20} /> Login / Sign Up
                  </Link>
                  <Link
                    to="/dashboard"
                    className="flex items-center justify-center gap-2 bg-primary text-primary-foreground py-2 rounded-md font-medium"
                  >
                    <LayoutDashboard size={20} /> Dashboard
                  </Link>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </header>

        <main className="flex-1 flex flex-col">
          {children}
        </main>

        <footer className="border-t border-border py-8 bg-muted/30">
          <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <div>&copy; {new Date().getFullYear()} GROE AI. All rights reserved.</div>
            <div className="flex gap-4">
              <Link to="/privacy" className="hover:text-foreground">Privacy Policy</Link>
              <Link to="/terms" className="hover:text-foreground">Terms of Service</Link>
              <Link to="/contact" className="hover:text-foreground">Contact Admin</Link>
            </div>
          </div>
        </footer>
      </div>
      <Chatbot />
    </div>
  );
}

export default function App() {
  const [isDark, setIsDark] = useState(true);

  const toggleTheme = () => setIsDark(!isDark);

  return (
    <Router>
      <Layout toggleTheme={toggleTheme} isDark={isDark}>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/generator" element={<GeneratorPage />} />
          <Route path="/marketplace" element={<MarketplacePage />} />
          <Route path="/pricing" element={<PricingPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/login" element={<LoginPage />} />
        </Routes>
      </Layout>
    </Router>
  );
}
